# # # ui.py
# # import pygame
# # import config as cfg

# # class Button:
# #     def __init__(self, text, x, y, w, h, color, callback=None, font=None):
# #         self.rect = pygame.Rect(x, y, w, h)
# #         self.text = text
# #         self.color = color
# #         self.callback = callback
# #         self.font = font or pygame.font.SysFont('arial', 32)
# #         self.hover = False
    
# #     def draw(self, surf):
# #         col = tuple(min(c + 40, 255) for c in self.color) if self.hover else self.color
# #         pygame.draw.rect(surf, col, self.rect, border_radius=12)
# #         pygame.draw.rect(surf, cfg.WHITE, self.rect, 2, border_radius=12)
# #         txt = self.font.render(self.text, True, (0,0,0))
# #         surf.blit(txt, (self.rect.centerx - txt.get_width()//2, self.rect.centery - txt.get_height()//2))
    
# #     def update(self, pos):
# #         self.hover = self.rect.collidepoint(pos)
    
# #     def click(self, pos):
# #         if self.hover and self.callback:
# #             self.callback()

# # class HUD:
# #     def __init__(self, font_l, font_m, font_s):
# #         self.fl = font_l
# #         self.fm = font_m
# #         self.fs = font_s
    
# #     def draw(self, surf, score, time_left, extra=""):
# #         surf.blit(self.fs.render(f"SCORE: {score}", True, cfg.WHITE), (20, 20))
# #         tc = cfg.NEON_RED if time_left < 10 else cfg.NEON_YELLOW
# #         surf.blit(self.fm.render(f"TIME: {int(time_left)}s", True, tc), (surf.get_width()//2 - 70, 15))
# #         if extra:
# #             surf.blit(self.fs.render(extra, True, cfg.NEON_GREEN), (surf.get_width() - 250, 20))

# # ui.py
# import pygame
# import config as cfg


# class Button:
#     def __init__(self, text, x, y, w, h, color, callback=None, font=None):
#         self.rect = pygame.Rect(x, y, w, h)
#         self.text = text
#         self.base_color = color
#         self.callback = callback
#         self.font = font or pygame.font.SysFont('arial', 32, bold=True)
#         self.hover = False
#         self.pressed = False

#     def draw(self, surf):
#         col = self.base_color
#         if self.pressed: col = tuple(max(c-40, 0) for c in col)
#         elif self.hover: col = tuple(min(c+30, 255) for c in col)
        
#         # Glow shadow
#         shadow_rect = self.rect.copy()
#         shadow_rect.y += 4
#         pygame.draw.rect(surf, (0,0,0,80), shadow_rect, border_radius=12)
        
#         # Main button
#         pygame.draw.rect(surf, col, self.rect, border_radius=12)
#         pygame.draw.rect(surf, cfg.WHITE, self.rect, 2, border_radius=12)
        
#         txt = self.font.render(self.text, True, BLACK := (10,10,15))
#         surf.blit(txt, (self.rect.centerx - txt.get_width()//2, self.rect.centery - txt.get_height()//2))

#     def update(self, pos, events):
#         self.hover = self.rect.collidepoint(pos)
#         self.pressed = any(e.type == pygame.MOUSEBUTTONDOWN and self.rect.collidepoint(e.pos) for e in events)
#         if self.pressed and self.callback:
#             self.callback()

# class HUD:
#     def __init__(self, font_l, font_m, font_s):
#         self.fl, self.fm, self.fs = font_l, font_m, font_s

#     def draw(self, surf, score, lives, extra="", is_timeless=False, time_left=0):
#         # Score
#         surf.blit(self.fs.render(f"SCORE: {score}", True, cfg.TEXT_PRIMARY), (40, 40))
        
#         # Lives (Hearts)
#         for i in range(3):
#             col = cfg.ACCENT_RED if i < lives else (60, 60, 70)
#             pygame.draw.circle(surf, col, (surf.get_width() - 60 - i*40, 50), 14)
#             pygame.draw.circle(surf, cfg.WHITE, (surf.get_width() - 60 - i*40, 50), 14, 2)
            
#         # Timer or Game Mode
#         if not is_timeless:
#             tc = cfg.ACCENT_RED if time_left < 10 else cfg.ACCENT_YELLOW
#             surf.blit(self.fm.render(f"TIME: {int(time_left)}s", True, tc), (surf.get_width()//2 - 70, 30))
#         else:
#             surf.blit(self.fm.render("TIMELESS", True, cfg.ACCENT_GREEN), (surf.get_width()//2 - 80, 30))
            
#         if extra:
#             surf.blit(self.fs.render(extra, True, cfg.ACCENT_ORANGE), (surf.get_width() - 280, 90))

# class ModalInput:
#     def __init__(self, prompt, options=None):
#         self.prompt = prompt
#         self.options = options
#         self.input_text = ""
#         self.selected_idx = 0
#         self.active = True

#     def draw(self, surf, font_l, font_m, font_s):
#         overlay = pygame.Surface(surf.get_size())
#         overlay.fill((0,0,0))
#         overlay.set_alpha(200)
#         surf.blit(overlay, (0,0))
        
#         title = font_m.render(self.prompt, True, cfg.ACCENT_YELLOW)
#         surf.blit(title, (surf.get_width()//2 - title.get_width()//2, 200))
        
#         if self.options:
#             for i, opt in enumerate(self.options):
#                 col = cfg.ACCENT_GREEN if i == self.selected_idx else cfg.TEXT_SECONDARY
#                 bg = (30, 40, 70) if i == self.selected_idx else (20, 25, 45)
#                 rect = pygame.Rect(surf.get_width()//2 - 200, 280 + i*70, 400, 55)
#                 pygame.draw.rect(surf, bg, rect, border_radius=10)
#                 pygame.draw.rect(surf, col, rect, 2 if i==self.selected_idx else 1, border_radius=10)
#                 txt = font_m.render(opt, True, col)
#                 surf.blit(txt, (rect.centerx - txt.get_width()//2, rect.centery - txt.get_height()//2))
#         else:
#             box = pygame.Rect(surf.get_width()//2 - 250, 280, 500, 65)
#             pygame.draw.rect(surf, (20, 25, 45), box, border_radius=12)
#             pygame.draw.rect(surf, cfg.ACCENT_GREEN, box, 3, border_radius=12)
#             cursor = "_" if pygame.time.get_ticks() % 1000 < 500 else ""
#             txt = font_m.render(self.input_text + cursor, True, cfg.TEXT_PRIMARY)
#             surf.blit(txt, (box.x + 20, box.y + 15))
            
#         hint = font_s.render("ENTER to confirm | ESC to cancel", True, cfg.TEXT_SECONDARY)
#         surf.blit(hint, (surf.get_width()//2 - hint.get_width()//2, 400))

# ui.py
# # ui.py
import pygame
import config as cfg

class Button:
    def __init__(self, text, x, y, w, h, color, callback=None, font=None):
        self.rect = pygame.Rect(x, y, w, h)
        self.text = text
        self.base_color = color
        self.callback = callback
        self.font = font or pygame.font.SysFont('arial', 32, bold=True)
        self.hover = False
        self.pressed = False
        self.hover_alpha = 0

    def draw(self, surf):
        # Smooth hover animation
        if self.hover and not self.pressed:
            self.hover_alpha = min(255, self.hover_alpha + 25)
        else:
            self.hover_alpha = max(0, self.hover_alpha - 25)

        col = self.base_color
        if self.pressed: 
            col = tuple(max(c-50, 0) for c in col)
        
        # Base shadow
        shadow_rect = self.rect.copy()
        shadow_rect.y += 6
        pygame.draw.rect(surf, (0, 0, 0, 100), shadow_rect, border_radius=12)
        
        # Outer neon glow when hovered
        if self.hover_alpha > 0:
            glow_surf = pygame.Surface((self.rect.w + 30, self.rect.h + 30), pygame.SRCALPHA)
            pygame.draw.rect(glow_surf, (*self.base_color[:3], int(self.hover_alpha * 0.3)), glow_surf.get_rect(), border_radius=18)
            surf.blit(glow_surf, (self.rect.x - 15, self.rect.y - 15))

        # Main button fill
        pygame.draw.rect(surf, col, self.rect, border_radius=12)
        
        # Border
        border_col = tuple(min(c+80, 255) for c in col)
        pygame.draw.rect(surf, border_col, self.rect, 2, border_radius=12)
        
        # Text
        txt = self.font.render(self.text, True, (10, 10, 15))
        surf.blit(txt, (self.rect.centerx - txt.get_width()//2, self.rect.centery - txt.get_height()//2))

    def update(self, pos, events):
        self.hover = self.rect.collidepoint(pos)
        self.pressed = any(e.type == pygame.MOUSEBUTTONDOWN and self.rect.collidepoint(e.pos) for e in events)
        if self.pressed and self.callback:
            self.callback()

class HUD:
    def __init__(self, font_l, font_m, font_s):
        self.fl, self.fm, self.fs = font_l, font_m, font_s

    def draw_text_with_shadow(self, surf, text, font, color, pos):
        shadow = font.render(text, True, (0, 0, 0))
        surf.blit(shadow, (pos[0] + 2, pos[1] + 2))
        main_text = font.render(text, True, color)
        surf.blit(main_text, pos)

    def draw(self, surf, score, lives, extra="", is_timeless=False, time_left=0):
        # Score
        self.draw_text_with_shadow(surf, f"SCORE: {score}", self.fs, cfg.TEXT_PRIMARY, (40, 40))
        
        # Lives (Hearts/Circles)
        for i in range(3):
            col = cfg.ACCENT_RED if i < lives else (60, 60, 70)
            center = (surf.get_width() - 60 - i*40, 50)
            # Inner glow
            pygame.draw.circle(surf, (*col[:3], 150), center, 18)
            pygame.draw.circle(surf, col, center, 14)
            pygame.draw.circle(surf, cfg.WHITE, center, 14, 2)
            
        # Timer or Game Mode
        if not is_timeless:
            tc = cfg.ACCENT_RED if time_left < 10 else cfg.ACCENT_YELLOW
            self.draw_text_with_shadow(surf, f"TIME: {int(time_left)}s", self.fm, tc, (surf.get_width()//2 - 70, 30))
        else:
            self.draw_text_with_shadow(surf, "TIMELESS", self.fm, cfg.ACCENT_GREEN, (surf.get_width()//2 - 80, 30))
            
        if extra:
            self.draw_text_with_shadow(surf, extra, self.fs, cfg.ACCENT_ORANGE, (surf.get_width() - 280, 90))

class ModalInput:
    def __init__(self, prompt, options=None):
        self.prompt = prompt
        self.options = options
        self.input_text = ""
        self.selected_idx = 0
        self.active = True

    def draw(self, surf, font_l, font_m, font_s):
        # Semi-transparent overlay
        overlay = pygame.Surface(surf.get_size(), pygame.SRCALPHA)
        overlay.fill((10, 12, 24, 200))
        surf.blit(overlay, (0,0))
        
        # Draw text shadow helper
        def draw_shadow_text(surface, text, font, color, center_pos):
            txt = font.render(text, True, color)
            shd = font.render(text, True, (0, 0, 0))
            surface.blit(shd, (center_pos[0] - shd.get_width()//2 + 3, center_pos[1] - shd.get_height()//2 + 3))
            surface.blit(txt, (center_pos[0] - txt.get_width()//2, center_pos[1] - txt.get_height()//2))

        draw_shadow_text(surf, self.prompt, font_m, cfg.ACCENT_YELLOW, (surf.get_width()//2, 220))
        
        if self.options:
            for i, opt in enumerate(self.options):
                col = cfg.ACCENT_GREEN if i == self.selected_idx else cfg.TEXT_SECONDARY
                bg = (40, 50, 80) if i == self.selected_idx else (25, 30, 50)
                
                rect = pygame.Rect(surf.get_width()//2 - 200, 280 + i*70, 400, 55)
                
                # Glow for selected option
                if i == self.selected_idx:
                    glow = pygame.Surface((rect.w + 10, rect.h + 10), pygame.SRCALPHA)
                    pygame.draw.rect(glow, (*cfg.ACCENT_GREEN[:3], 60), glow.get_rect(), border_radius=12)
                    surf.blit(glow, (rect.x - 5, rect.y - 5))
                
                pygame.draw.rect(surf, bg, rect, border_radius=12)
                pygame.draw.rect(surf, col, rect, 2 if i==self.selected_idx else 1, border_radius=12)
                
                txt = font_m.render(opt, True, col)
                surf.blit(txt, (rect.centerx - txt.get_width()//2, rect.centery - txt.get_height()//2))
        else:
            box = pygame.Rect(surf.get_width()//2 - 250, 280, 500, 65)
            pygame.draw.rect(surf, (25, 30, 50), box, border_radius=12)
            pygame.draw.rect(surf, cfg.ACCENT_GREEN, box, 3, border_radius=12)
            
            cursor = "_" if pygame.time.get_ticks() % 1000 < 500 else ""
            txt = font_m.render(self.input_text + cursor, True, cfg.TEXT_PRIMARY)
            surf.blit(txt, (box.x + 20, box.y + 15))
            
        draw_shadow_text(surf, "ENTER to confirm | ESC to cancel", font_s, cfg.TEXT_SECONDARY, (surf.get_width()//2, 420))