# # graphics.py
# import pygame
# import random

# class Particle:
#     def __init__(self, x, y, color, speed=3, life=1.0):
#         self.x, self.y = x, y
#         self.color = color
#         self.vx, self.vy = random.uniform(-speed, speed), random.uniform(-speed, speed)
#         self.life, self.max_life = life, life
#         self.size = random.randint(2, 6)
#     def update(self, dt):
#         self.x += self.vx * dt; self.y += self.vy * dt
#         self.vy += 200 * dt
#         self.life -= dt
#     def draw(self, surf):
#         if self.life <= 0: return
#         a = int(255 * (self.life / self.max_life))
#         s = max(1, int(self.size * (self.life / self.max_life)))
#         pygame.draw.circle(surf, (*self.color[:3], a), (int(self.x), int(self.y)), s)

# class Background:
#     def __init__(self, w, h):
#         self.w, self.h = w, h
#         self.offset = 0
#     def draw(self, surf, dt=0.016):
#         self.offset = (self.offset + 20 * dt) % 50
#         for x in range(-50, self.w + 50, 50):
#             pygame.draw.line(surf, (30, 30, 60), (x, 0), (x, self.h))
#         for y in range(int(-50 + self.offset), self.h + 50, 50):
#             pygame.draw.line(surf, (30, 30, 60), (0, y), (self.w, y))

# graphics.py
import pygame
import random
import math

from config import BG_SECONDARY, GRID_COLOR, BG_PRIMARY

class Particle:
    def __init__(self, x, y, color, speed=4, life=1.0, size=4):
        self.x, self.y = x, y
        self.color = color
        angle = random.uniform(0, math.pi * 2)
        self.vx = math.cos(angle) * speed * random.uniform(0.5, 1.5)
        self.vy = math.sin(angle) * speed * random.uniform(0.5, 1.5)
        self.life, self.max_life = life, life
        self.size = size
        self.decay = random.uniform(0.8, 1.2)
        self.history = [(x, y)]

    def update(self, dt):
        self.x += self.vx * dt * 60
        self.y += self.vy * dt * 60
        self.vy += 150 * dt  # gravity
        self.life -= dt * self.decay
        self.history.append((self.x, self.y))
        if len(self.history) > 6:
            self.history.pop(0)

    def draw(self, surf):
        if self.life <= 0: return
        alpha = int(255 * (self.life / self.max_life))
        sz = max(1, int(self.size * (self.life / self.max_life)))
        
        # Create a small surface for alpha drawing
        p_surf = pygame.Surface((sz*8, sz*8), pygame.SRCALPHA)
        center = (sz*4, sz*4)
        
        # Glow effect
        for r in range(sz, sz+4):
            a = int(alpha * (1 - (r - sz)/4))
            pygame.draw.circle(p_surf, (*self.color[:3], a), center, r)
            
        surf.blit(p_surf, (int(self.x) - center[0], int(self.y) - center[1]))
        
        # Draw trail
        if len(self.history) > 1:
            pygame.draw.lines(surf, self.color, False, self.history, max(1, sz-1))

class Background:
    def __init__(self, w, h):
        self.w, self.h = w, h
        self.offset = 0
        self.grad = pygame.Surface((w, h))
        for y in range(h):
            ratio = y / h
            r = int(BG_PRIMARY[0] * (1-ratio) + BG_SECONDARY[0] * ratio)
            g = int(BG_PRIMARY[1] * (1-ratio) + BG_SECONDARY[1] * ratio)
            b = int(BG_PRIMARY[2] * (1-ratio) + BG_SECONDARY[2] * ratio)
            pygame.draw.line(self.grad, (r, g, b), (0, y), (w, y))

    def draw(self, surf, dt=0.016):
        surf.blit(self.grad, (0, 0))
        self.offset = (self.offset + 25 * dt) % 60
        
        grid_surf = pygame.Surface((self.w, self.h), pygame.SRCALPHA)
        grid_alpha = int(40 + 20 * math.sin(pygame.time.get_ticks() / 1000.0))
        col = (*GRID_COLOR[:3], grid_alpha)
        
        for x in range(-60, self.w + 60, 60):
            pygame.draw.line(grid_surf, col, (x, 0), (x, self.h), 1)
        for y in range(int(-60 + self.offset), self.h + 60, 60):
            pygame.draw.line(grid_surf, col, (0, y), (self.w, y), 1)
            
        surf.blit(grid_surf, (0, 0))