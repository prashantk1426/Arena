

# # main.py
# import pygame
# import sys
# import config as cfg
# from audio import AudioManager
# from graphics import Background, Particle
# from ui import Button, HUD
# from game_collector import ArenaGame
# from game_dodge import DodgeGame
# from game_reaction import ReactionGame
# from leaderboard import Leaderboard

# def main():
#     pygame.init()
#     pygame.mixer.init(frequency=22050, size=-16, channels=2, buffer=512)
#     screen = pygame.display.set_mode((cfg.SCREEN_WIDTH, cfg.SCREEN_HEIGHT))
#     pygame.display.set_caption("ARENA")
#     clock = pygame.time.Clock()

#     fL = pygame.font.SysFont('arial', 64, bold=True)
#     fM = pygame.font.SysFont('arial', 40, bold=True)
#     fS = pygame.font.SysFont('arial', 28)

#     audio = AudioManager()
#     bg = Background(cfg.SCREEN_WIDTH, cfg.SCREEN_HEIGHT)
#     hud = HUD(fL, fM, fS)
#     lb = Leaderboard()
#     particles = []

#     games = {
#         'collector': ArenaGame(audio, hud, particles),
#         'dodge': DodgeGame(audio, hud, particles),
#         'reaction': ReactionGame(audio, hud, particles)
#     }

#     current_game = None
#     game_name = ""
#     state = 'menu'
#     final_score = 0
#     is_paused = False

#     # Pause menu buttons
#     pause_resume_btn = Button("RESUME", 420, 350, 360, 60, cfg.NEON_GREEN, None, fM)
#     pause_menu_btn = Button("MAIN MENU", 420, 430, 360, 60, cfg.NEON_RED, None, fM)

#     def go_back():
#         nonlocal state, current_game, is_paused
#         state = 'menu'
#         current_game = None
#         is_paused = False
#         audio.start_lobby_music()

#     menu_btns = [
#         Button("COLLECTOR", 420, 250, 360, 60, cfg.NEON_GREEN, lambda: start_game('collector', 'COLLECTOR'), fM),
#         Button("NEON DODGE", 420, 330, 360, 60, cfg.NEON_ORANGE, lambda: start_game('dodge', 'NEON DODGE'), fM),
#         Button("REACTION RUSH", 420, 410, 360, 60, cfg.NEON_PINK, lambda: start_game('reaction', 'REACTION RUSH'), fM),
#         Button("LEADERBOARD", 420, 490, 360, 60, cfg.NEON_YELLOW, lambda: set_state('leaderboard'), fM),
#         Button("QUIT", 420, 570, 360, 60, cfg.NEON_RED, lambda: [pygame.quit(), sys.exit()], fM)
#     ]

#     def start_game(key, name):
#         nonlocal state, current_game, game_name, particles
#         state = 'playing'
#         current_game = games[key]
#         particles.clear()
#         current_game.reset()
#         game_name = name
#         audio.stop_music()
#         is_paused = False

#     def set_state(s):
#         nonlocal state
#         state = s
#         audio.stop_music()

#     audio.start_lobby_music()

#     running = True
#     while running:
#         dt = clock.tick(cfg.FPS) / 1000.0
#         clicks = []
#         for ev in pygame.event.get():
#             if ev.type == pygame.QUIT: running = False
#             if ev.type == pygame.MOUSEBUTTONDOWN: clicks.append(ev.pos)
            
#             # ESC KEY HANDLER
#             if ev.type == pygame.KEYDOWN and ev.key == pygame.K_ESCAPE:
#                 if state == 'playing':
#                     is_paused = not is_paused
#                 elif state == 'gameover':
#                     go_back()

#         screen.fill(cfg.DARK_BG)
#         bg.draw(screen, dt)

#         if state == 'menu':
#             title = fL.render("ARENA", True, cfg.NEON_BLUE)
#             screen.blit(title, (cfg.SCREEN_WIDTH//2 - title.get_width()//2, 100))
#             sub = fS.render("Choose your challenge", True, cfg.WHITE)
#             screen.blit(sub, (cfg.SCREEN_WIDTH//2 - sub.get_width()//2, 170))
#             pos = pygame.mouse.get_pos()
#             for b in menu_btns: b.update(pos); b.draw(screen)
#             for c in clicks:
#                 for b in menu_btns: b.click(c)

#         elif state == 'playing' and current_game:
#             if not is_paused:
#                 final_score = current_game.update(dt, pygame.key.get_pressed(), clicks)
#                 current_game.draw(screen)
                
#                 if not current_game.running:
#                     state = 'gameover'
#                     lb.add("Player", final_score, game_name)
#                     audio.play_sfx(523, 0.5, 0.4)
#             else:
#                 # DRAW PAUSE OVERLAY
#                 overlay = pygame.Surface(screen.get_size())
#                 overlay.fill((0, 0, 0))
#                 overlay.set_alpha(180)
#                 screen.blit(overlay, (0, 0))
                
#                 pause_text = fL.render("PAUSED", True, cfg.NEON_YELLOW)
#                 screen.blit(pause_text, (cfg.SCREEN_WIDTH//2 - pause_text.get_width()//2, 220))
                
#                 pos = pygame.mouse.get_pos()
#                 pause_resume_btn.update(pos)
#                 pause_resume_btn.draw(screen)
#                 pause_menu_btn.update(pos)
#                 pause_menu_btn.draw(screen)
                
#                 for c in clicks:
#                     if pause_resume_btn.rect.collidepoint(c):
#                         is_paused = False
#                     if pause_menu_btn.rect.collidepoint(c):
#                         go_back()

#         elif state == 'gameover':
#             overlay = pygame.Surface(screen.get_size()); overlay.fill((0,0,0)); overlay.set_alpha(200)
#             screen.blit(overlay, (0,0))
#             win = fL.render("GAME OVER", True, cfg.NEON_YELLOW)
#             screen.blit(win, (cfg.SCREEN_WIDTH//2 - win.get_width()//2, 250))
#             sc = fM.render(f"FINAL SCORE: {final_score}", True, cfg.WHITE)
#             screen.blit(sc, (cfg.SCREEN_WIDTH//2 - sc.get_width()//2, 350))
#             # Re-use pause buttons for game over screen
#             pos = pygame.mouse.get_pos()
#             pause_resume_btn.text = "PLAY AGAIN"
#             pause_resume_btn.callback = lambda: start_game(games.keys().__iter__().__next__(), game_name) # fallback
#             pause_resume_btn.update(pos); pause_resume_btn.draw(screen)
#             pause_menu_btn.update(pos); pause_menu_btn.draw(screen)
#             for c in clicks:
#                 if pause_resume_btn.rect.collidepoint(c):
#                     start_game(list(games.keys())[0] if game_name == 'COLLECTOR' else 
#                                'dodge' if game_name == 'NEON DODGE' else 'reaction', game_name)
#                 if pause_menu_btn.rect.collidepoint(c):
#                     go_back()

#         elif state == 'leaderboard':
#             title = fL.render("LEADERBOARD", True, cfg.NEON_YELLOW)
#             screen.blit(title, (cfg.SCREEN_WIDTH//2 - title.get_width()//2, 80))
#             top = lb.scores[:10]
#             for i, e in enumerate(top):
#                 c = cfg.NEON_YELLOW if i==0 else cfg.NEON_BLUE if i<3 else cfg.WHITE
#                 s = fS.render(f"{i+1}. {e['name']} - {e['score']} pts ({e['game']})", True, c)
#                 screen.blit(s, (cfg.SCREEN_WIDTH//2 - s.get_width()//2, 180 + i*50))
#             pos = pygame.mouse.get_pos()
#             pause_menu_btn.text = "BACK"
#             pause_menu_btn.callback = go_back
#             pause_menu_btn.update(pos); pause_menu_btn.draw(screen)
#             for c in clicks:
#                 if pause_menu_btn.rect.collidepoint(c): go_back()

#         for p in particles[:]: p.update(dt); p.draw(screen)
#         particles[:] = [p for p in particles if p.life > 0]

#         pygame.display.flip()

#     pygame.quit()

# if __name__ == "__main__":
#     main()

# main.py
# import pygame
# import sys
# import config as cfg
# from audio import AudioManager
# from graphics import Background, Particle
# from ui import Button, HUD, ModalInput
# from game_collector import ArenaGame
# from game_dodge import DodgeGame
# from game_reaction import ReactionGame
# from leaderboard import Leaderboard

# def main():
#     pygame.init()
#     pygame.mixer.init(frequency=22050, size=-16, channels=2, buffer=512)
#     # Fullscreen initialization
#     screen = pygame.display.set_mode((cfg.SCREEN_WIDTH, cfg.SCREEN_HEIGHT), pygame.FULLSCREEN | pygame.HWSURFACE)
#     pygame.display.set_caption("ARENA - Professional Arcade Suite")
#     clock = pygame.time.Clock()

#     fL = pygame.font.SysFont('arial', 72, bold=True)
#     fM = pygame.font.SysFont('arial', 44, bold=True)
#     fS = pygame.font.SysFont('arial', 30)

#     audio = AudioManager()
#     bg = Background(cfg.SCREEN_WIDTH, cfg.SCREEN_HEIGHT)
#     hud = HUD(fL, fM, fS)
#     lb = Leaderboard()
#     particles = []

#     games = {
#         'collector': ArenaGame(audio, hud, particles),
#         'dodge': DodgeGame(audio, hud, particles),
#         'reaction': ReactionGame(audio, hud, particles)
#     }

#     current_game = None
#     game_name = ""
#     player_name = ""
#     selected_difficulty = "MEDIUM"
#     state = 'menu' # menu, input_name, input_diff, playing, paused, gameover, leaderboard
#     final_score = 0
#     is_paused = False
#     modal = None
#     selected_game_key = None

#     pause_resume_btn = Button("RESUME", cfg.SCREEN_WIDTH//2-180, 350, 360, 60, cfg.ACCENT_GREEN, None, fM)
#     pause_menu_btn = Button("MAIN MENU", cfg.SCREEN_WIDTH//2-180, 430, 360, 60, cfg.ACCENT_RED, None, fM)

#     def go_back():
#         nonlocal state, current_game, is_paused, modal
#         state = 'menu'
#         current_game = None
#         is_paused = False
#         modal = None
#         audio.start_lobby_music()

#     menu_btns = [
#         Button("COLLECTOR", cfg.SCREEN_WIDTH//2-180, 250, 360, 60, cfg.ACCENT_GREEN, lambda: prep_start('collector', 'COLLECTOR'), fM),
#         Button("NEON DODGE", cfg.SCREEN_WIDTH//2-180, 330, 360, 60, cfg.ACCENT_ORANGE, lambda: prep_start('dodge', 'NEON DODGE'), fM),
#         Button("REACTION RUSH", cfg.SCREEN_WIDTH//2-180, 410, 360, 60, cfg.ACCENT_PINK, lambda: prep_start('reaction', 'REACTION RUSH'), fM),
#         Button("LEADERBOARD", cfg.SCREEN_WIDTH//2-180, 490, 360, 60, cfg.ACCENT_YELLOW, lambda: set_state('leaderboard'), fM),
#         Button("QUIT", cfg.SCREEN_WIDTH//2-180, 570, 360, 60, cfg.ACCENT_RED, lambda: [pygame.quit(), sys.exit()], fM)
#     ]

#     def prep_start(key, name):
#         nonlocal state, selected_game_key, modal
#         selected_game_key = key
#         game_name = name
#         state = 'input_name'
#         modal = ModalInput("ENTER PLAYER NAME:")
#         audio.stop_music()

#     def set_state(s):
#         nonlocal state
#         state = s

#     audio.start_lobby_music()
#     running = True

#     while running:
#         dt = clock.tick(cfg.FPS) / 1000.0
#         events = pygame.event.get()
#         clicks = [e.pos for e in events if e.type == pygame.MOUSEBUTTONDOWN]
#         pos = pygame.mouse.get_pos()

#         for ev in events:
#             if ev.type == pygame.QUIT: running = False
#             if ev.type == pygame.KEYDOWN and ev.key == pygame.K_ESCAPE:
#                 if state == 'playing': is_paused = not is_paused
#                 elif state in ['gameover', 'leaderboard', 'input_name', 'input_diff']: go_back()
#                 elif state == 'menu': pass

#         screen.fill(cfg.BG_PRIMARY)
#         bg.draw(screen, dt)

#         if state == 'menu':
#             title = fL.render("ARENA", True, cfg.ACCENT_BLUE)
#             screen.blit(title, (cfg.SCREEN_WIDTH//2 - title.get_width()//2, 120))
#             sub = fS.render("Professional Interactive Arcade Suite", True, cfg.TEXT_SECONDARY)
#             screen.blit(sub, (cfg.SCREEN_WIDTH//2 - sub.get_width()//2, 190))
#             for b in menu_btns: b.update(pos, events); b.draw(screen)

#         elif state in ['input_name', 'input_diff']:
#             modal.draw(screen, fL, fM, fS)
#             for ev in events:
#                 if ev.type == pygame.KEYDOWN:
#                     if state == 'input_name':
#                         if ev.key == pygame.K_RETURN and modal.input_text.strip():
#                             state = 'input_diff' if selected_game_key != 'dodge' else 'playing'
#                             player_name = modal.input_text.strip()
#                             if state == 'playing': start_game()
#                             else: modal = ModalInput("SELECT DIFFICULTY:", options=cfg.DIFFICULTIES)
#                         elif ev.key == pygame.K_BACKSPACE: modal.input_text = modal.input_text[:-1]
#                         elif ev.unicode.isalpha() and len(modal.input_text) < 15: modal.input_text += ev.unicode
#                     elif state == 'input_diff':
#                         if ev.key == pygame.K_RETURN: start_game()
#                         elif ev.key == pygame.K_UP: modal.selected_idx = (modal.selected_idx - 1) % len(modal.options)
#                         elif ev.key == pygame.K_DOWN: modal.selected_idx = (modal.selected_idx + 1) % len(modal.options)

#         elif state == 'playing' and current_game:
#             if not is_paused:
#                 res = current_game.update(dt, pygame.key.get_pressed(), clicks)
#                 final_score, lives = res[0], res[1]
#                 current_game.draw(screen)
#                 if not current_game.running:
#                     state = 'gameover'
#                     lb.add(player_name, final_score, game_name, getattr(current_game, 'difficulty', 'N/A'))
#                     audio.play_sfx(523, 0.5, 0.4)
#             else:
#                 overlay = pygame.Surface(screen.get_size()); overlay.fill((0,0,0)); overlay.set_alpha(180)
#                 screen.blit(overlay, (0,0))
#                 screen.blit(fL.render("PAUSED", True, cfg.ACCENT_YELLOW), (cfg.SCREEN_WIDTH//2-100, 220))
#                 pause_resume_btn.update(pos, events); pause_resume_btn.draw(screen)
#                 pause_menu_btn.update(pos, events); pause_menu_btn.draw(screen)
#                 for c in clicks:
#                     if pause_resume_btn.rect.collidepoint(c): is_paused = False
#                     if pause_menu_btn.rect.collidepoint(c): go_back()

#         elif state == 'gameover':
#             overlay = pygame.Surface(screen.get_size()); overlay.fill((0,0,0)); overlay.set_alpha(200)
#             screen.blit(overlay, (0,0))
#             screen.blit(fL.render("GAME OVER", True, cfg.ACCENT_RED), (cfg.SCREEN_WIDTH//2-180, 180))
#             screen.blit(fM.render(f"Player: {player_name}", True, cfg.ACCENT_BLUE), (cfg.SCREEN_WIDTH//2-150, 280))
#             screen.blit(fL.render(f"SCORE: {final_score}", True, cfg.ACCENT_YELLOW), (cfg.SCREEN_WIDTH//2-150, 350))
#             pause_resume_btn.text = "PLAY AGAIN"; pause_resume_btn.update(pos, events); pause_resume_btn.draw(screen)
#             pause_menu_btn.update(pos, events); pause_menu_btn.draw(screen)
#             for c in clicks:
#                 if pause_resume_btn.rect.collidepoint(c): start_game(); is_paused=False
#                 if pause_menu_btn.rect.collidepoint(c): go_back()

#         elif state == 'leaderboard':
#             screen.blit(fL.render("LEADERBOARD", True, cfg.ACCENT_YELLOW), (cfg.SCREEN_WIDTH//2-180, 80))
#             top = lb.scores[:12]
#             for i, e in enumerate(top):
#                 c = cfg.ACCENT_YELLOW if i==0 else cfg.ACCENT_BLUE if i<3 else cfg.TEXT_PRIMARY
#                 s = fS.render(f"{i+1}. {e['name']} | {e['score']} pts | {e['game']} ({e['diff']})", True, c)
#                 screen.blit(s, (cfg.SCREEN_WIDTH//2 - s.get_width()//2, 180 + i*55))
#             # ESC handles back, no button needed

#         for p in particles[:]: p.update(dt); p.draw(screen)
#         particles[:] = [p for p in particles if p.life > 0]
#         pygame.display.flip()

#     def start_game():
#         nonlocal state, current_game, is_paused, modal
#         state = 'playing'
#         current_game = games[selected_game_key]
#         particles.clear()
#         diff = selected_difficulty if selected_game_key != 'dodge' else "MEDIUM"
#         current_game.reset(diff)
#         is_paused = False
#         modal = None

#     pygame.quit()

# if __name__ == "__main__":
#     main()

# main.py
# main.py
# import pygame
# import sys
# import config as cfg
# from audio import AudioManager
# from graphics import Background, Particle
# from ui import Button, HUD, ModalInput
# from game_collector import ArenaGame
# from game_dodge import DodgeGame
# from game_reaction import ReactionGame
# from leaderboard import Leaderboard

# def main():
#     pygame.init()
#     pygame.mixer.init(frequency=22050, size=-16, channels=2, buffer=512)
#     screen = pygame.display.set_mode((cfg.SCREEN_WIDTH, cfg.SCREEN_HEIGHT), pygame.FULLSCREEN | pygame.HWSURFACE)
#     pygame.display.set_caption("ARENA - Professional Arcade Suite")
#     clock = pygame.time.Clock()

#     fL = pygame.font.SysFont('arial', 72, bold=True)
#     fM = pygame.font.SysFont('arial', 44, bold=True)
#     fS = pygame.font.SysFont('arial', 30)

#     audio = AudioManager()
#     bg = Background(cfg.SCREEN_WIDTH, cfg.SCREEN_HEIGHT)
#     hud = HUD(fL, fM, fS)
#     lb = Leaderboard()
#     particles = []

#     games = {
#         'collector': ArenaGame(audio, hud, particles),
#         'dodge': DodgeGame(audio, hud, particles),
#         'reaction': ReactionGame(audio, hud, particles)
#     }

#     current_game = None
#     game_name = ""
#     player_name = ""
#     selected_difficulty = "MEDIUM"
#     state = 'menu'
#     final_score = 0
#     is_paused = False
#     modal = None
#     selected_game_key = None

#     pause_resume_btn = Button("RESUME", cfg.SCREEN_WIDTH//2-180, 350, 360, 60, cfg.ACCENT_GREEN, None, fM)
#     pause_menu_btn = Button("MAIN MENU", cfg.SCREEN_WIDTH//2-180, 430, 360, 60, cfg.ACCENT_RED, None, fM)

#     def go_back():
#         nonlocal state, current_game, is_paused, modal
#         state = 'menu'
#         current_game = None
#         is_paused = False
#         modal = None
#         audio.start_lobby_music()

#     def start_game():
#         nonlocal state, current_game, is_paused, modal, selected_difficulty
#         state = 'playing'
#         current_game = games[selected_game_key]
#         particles.clear()
#         diff = selected_difficulty if selected_game_key != 'dodge' else "MEDIUM"
#         current_game.reset(diff)
#         is_paused = False
#         modal = None

#     def prep_start(key, name):
#         nonlocal state, selected_game_key, modal
#         selected_game_key = key
#         state = 'input_name'
#         modal = ModalInput("ENTER PLAYER NAME:")
#         audio.stop_music()

#     menu_btns = [
#         Button("COLLECTOR", cfg.SCREEN_WIDTH//2-180, 250, 360, 60, cfg.ACCENT_GREEN, lambda: prep_start('collector', 'COLLECTOR'), fM),
#         Button("NEON DODGE", cfg.SCREEN_WIDTH//2-180, 330, 360, 60, cfg.ACCENT_ORANGE, lambda: prep_start('dodge', 'NEON DODGE'), fM),
#         Button("REACTION RUSH", cfg.SCREEN_WIDTH//2-180, 410, 360, 60, cfg.ACCENT_PINK, lambda: prep_start('reaction', 'REACTION RUSH'), fM),
#         Button("LEADERBOARD", cfg.SCREEN_WIDTH//2-180, 490, 360, 60, cfg.ACCENT_YELLOW, lambda: set_state('leaderboard'), fM),
#         Button("QUIT", cfg.SCREEN_WIDTH//2-180, 570, 360, 60, cfg.ACCENT_RED, lambda: [pygame.quit(), sys.exit()], fM)
#     ]

#     def set_state(s):
#         nonlocal state
#         state = s

#     audio.start_lobby_music()
#     running = True

#     while running:
#         dt = clock.tick(cfg.FPS) / 1000.0
#         events = pygame.event.get()
#         clicks = [e.pos for e in events if e.type == pygame.MOUSEBUTTONDOWN]
#         pos = pygame.mouse.get_pos()

#         for ev in events:
#             if ev.type == pygame.QUIT: running = False
#             if ev.type == pygame.KEYDOWN and ev.key == pygame.K_ESCAPE:
#                 if state == 'playing': is_paused = not is_paused
#                 elif state in ['gameover', 'leaderboard', 'input_name', 'input_diff']: go_back()

#         screen.fill(cfg.BG_PRIMARY)
#         bg.draw(screen, dt)

#         if state == 'menu':
#             title = fL.render("ARENA", True, cfg.ACCENT_BLUE)
#             screen.blit(title, (cfg.SCREEN_WIDTH//2 - title.get_width()//2, 120))
#             sub = fS.render("Professional Interactive Arcade Suite", True, cfg.TEXT_SECONDARY)
#             screen.blit(sub, (cfg.SCREEN_WIDTH//2 - sub.get_width()//2, 190))
#             for b in menu_btns: b.update(pos, events); b.draw(screen)

#         elif state == 'input_name':
#             modal.draw(screen, fL, fM, fS)
#             for ev in events:
#                 if ev.type == pygame.KEYDOWN:
#                     if ev.key == pygame.K_RETURN and modal.input_text.strip():
#                         player_name = modal.input_text.strip()
#                         if selected_game_key == 'dodge':
#                             start_game()
#                         else:
#                             state = 'input_diff'
#                             modal = ModalInput("SELECT DIFFICULTY:", options=cfg.DIFFICULTIES)
#                     elif ev.key == pygame.K_BACKSPACE: modal.input_text = modal.input_text[:-1]
#                     elif ev.unicode.isalpha() and len(modal.input_text) < 15: modal.input_text += ev.unicode

#         elif state == 'input_diff':
#             modal.draw(screen, fL, fM, fS)
#             # Draw hint text BELOW the modal
#             hint_text = fS.render("Use UP/DOWN arrows to select | ENTER to confirm", True, cfg.ACCENT_YELLOW)
#             screen.blit(hint_text, (cfg.SCREEN_WIDTH//2 - hint_text.get_width()//2, 450))
            
#             for ev in events:
#                 if ev.type == pygame.KEYDOWN:
#                     if ev.key == pygame.K_RETURN:
#                         selected_difficulty = modal.options[modal.selected_idx]
#                         start_game()
#                     elif ev.key == pygame.K_UP: modal.selected_idx = (modal.selected_idx - 1) % len(modal.options)
#                     elif ev.key == pygame.K_DOWN: modal.selected_idx = (modal.selected_idx + 1) % len(modal.options)

#         elif state == 'playing' and current_game:
#             if not is_paused:
#                 res = current_game.update(dt, pygame.key.get_pressed(), clicks)
#                 final_score, lives = res[0], res[1]
#                 current_game.draw(screen)
#                 if not current_game.running:
#                     state = 'gameover'
#                     lb.add(player_name, final_score, game_name, getattr(current_game, 'difficulty', 'N/A'))
#                     audio.play_sfx(523, 0.5, 0.4)
#             else:
#                 overlay = pygame.Surface(screen.get_size()); overlay.fill((0,0,0)); overlay.set_alpha(220)
#                 screen.blit(overlay, (0,0))
#                 screen.blit(fL.render("PAUSED", True, cfg.ACCENT_YELLOW), (cfg.SCREEN_WIDTH//2-100, 220))
#                 pause_resume_btn.update(pos, events); pause_resume_btn.draw(screen)
#                 pause_menu_btn.update(pos, events); pause_menu_btn.draw(screen)
#                 for c in clicks:
#                     if pause_resume_btn.rect.collidepoint(c): is_paused = False
#                     if pause_menu_btn.rect.collidepoint(c): go_back()

#         elif state == 'gameover':
#             # Full dark overlay to prevent overlapping
#             overlay = pygame.Surface(screen.get_size()); overlay.fill(cfg.BG_PRIMARY); overlay.set_alpha(240)
#             screen.blit(overlay, (0,0))
            
#             # Draw decorative elements behind text
#             pygame.draw.rect(screen, (20, 25, 45), (cfg.SCREEN_WIDTH//2-250, 150, 500, 350), border_radius=15)
#             pygame.draw.rect(screen, cfg.ACCENT_BLUE, (cfg.SCREEN_WIDTH//2-250, 150, 500, 350), 3, border_radius=15)
            
#             screen.blit(fL.render("GAME OVER", True, cfg.ACCENT_RED), (cfg.SCREEN_WIDTH//2-180, 180))
#             screen.blit(fM.render(f"Player: {player_name}", True, cfg.ACCENT_BLUE), (cfg.SCREEN_WIDTH//2-150, 260))
#             screen.blit(fL.render(f"SCORE: {final_score}", True, cfg.ACCENT_YELLOW), (cfg.SCREEN_WIDTH//2-150, 320))
            
#             pause_resume_btn.text = "PLAY AGAIN"
#             pause_resume_btn.rect.y = 420
#             pause_menu_btn.rect.y = 500
#             pause_resume_btn.update(pos, events); pause_resume_btn.draw(screen)
#             pause_menu_btn.update(pos, events); pause_menu_btn.draw(screen)
            
#             for c in clicks:
#                 if pause_resume_btn.rect.collidepoint(c): start_game(); is_paused=False
#                 if pause_menu_btn.rect.collidepoint(c): go_back()

#         elif state == 'leaderboard':
#             # Full background overlay
#             overlay = pygame.Surface(screen.get_size()); overlay.fill(cfg.BG_PRIMARY); overlay.set_alpha(240)
#             screen.blit(overlay, (0,0))
            
#             # Draw container
#             pygame.draw.rect(screen, (20, 25, 45), (cfg.SCREEN_WIDTH//2-350, 60, 700, 600), border_radius=15)
#             pygame.draw.rect(screen, cfg.ACCENT_YELLOW, (cfg.SCREEN_WIDTH//2-350, 60, 700, 600), 3, border_radius=15)
            
#             screen.blit(fL.render("LEADERBOARD", True, cfg.ACCENT_YELLOW), (cfg.SCREEN_WIDTH//2-180, 80))
            
#             # FIXED: Handle missing 'diff' key gracefully
#             top = lb.scores[:12]
#             for i, e in enumerate(top):
#                 c = cfg.ACCENT_YELLOW if i==0 else cfg.ACCENT_BLUE if i<3 else cfg.TEXT_PRIMARY
#                 # Safely get difficulty with default value
#                 diff = e.get('diff', 'N/A')
#                 game = e.get('game', 'UNKNOWN')
#                 name = e.get('name', 'Player')
#                 score = e.get('score', 0)
                
#                 s = fS.render(f"{i+1}. {name} | {score} pts | {game} ({diff})", True, c)
#                 screen.blit(s, (cfg.SCREEN_WIDTH//2 - s.get_width()//2, 160 + i*50))
            
#             # ESC hint
#             esc_hint = fS.render("Press ESC to go back", True, cfg.TEXT_SECONDARY)
#             screen.blit(esc_hint, (cfg.SCREEN_WIDTH//2 - esc_hint.get_width()//2, 680))

#         for p in particles[:]: p.update(dt); p.draw(screen)
#         particles[:] = [p for p in particles if p.life > 0]
#         pygame.display.flip()

#     pygame.quit()

# if __name__ == "__main__":
#     main()

# main.py
import pygame
import sys
import config as cfg
from audio import AudioManager
from graphics import Background, Particle
from ui import Button, HUD, ModalInput
from game_collector import ArenaGame
from game_dodge import DodgeGame
from game_reaction import ReactionGame
from leaderboard import Leaderboard

def main():
    pygame.init()
    pygame.mixer.init(frequency=22050, size=-16, channels=2, buffer=512)
    screen = pygame.display.set_mode((cfg.SCREEN_WIDTH, cfg.SCREEN_HEIGHT), pygame.FULLSCREEN | pygame.HWSURFACE)
    pygame.display.set_caption("ARENA - Professional Arcade Suite")
    clock = pygame.time.Clock()

    def get_font(size, is_bold=False):
        return pygame.font.SysFont('impact,trebuchetms,segoeui,arial', size, bold=is_bold)

    fL = get_font(80)
    fM = get_font(32, True)
    fS = get_font(24, True)

    def draw_glowing_text(surf, text, font, color, center_pos):
        # Shadow
        shd = font.render(text, True, (0, 0, 0))
        surf.blit(shd, (center_pos[0] - shd.get_width()//2 + 4, center_pos[1] - shd.get_height()//2 + 4))
        # Main text
        txt = font.render(text, True, color)
        surf.blit(txt, (center_pos[0] - txt.get_width()//2, center_pos[1] - txt.get_height()//2))

    audio = AudioManager()
    bg = Background(cfg.SCREEN_WIDTH, cfg.SCREEN_HEIGHT)
    hud = HUD(fL, fM, fS)
    lb = Leaderboard()
    particles = []

    games = {
        'collector': ArenaGame(audio, hud, particles),
        'dodge': DodgeGame(audio, hud, particles),
        'reaction': ReactionGame(audio, hud, particles)
    }

    current_game = None
    game_name = ""
    player_name = ""
    selected_difficulty = "MEDIUM"
    state = 'menu'
    final_score = 0
    is_paused = False
    modal = None
    selected_game_key = None

    pause_resume_btn = Button("RESUME", cfg.SCREEN_WIDTH//2-180, 350, 360, 60, cfg.ACCENT_GREEN, None, fM)
    pause_menu_btn = Button("MAIN MENU", cfg.SCREEN_WIDTH//2-180, 430, 360, 60, cfg.ACCENT_RED, None, fM)

    def go_back():
        nonlocal state, current_game, is_paused, modal
        state = 'menu'
        current_game = None
        is_paused = False
        modal = None
        audio.start_lobby_music()

    def start_game():
        nonlocal state, current_game, is_paused, modal, selected_difficulty
        state = 'playing'
        current_game = games[selected_game_key]
        particles.clear()
        diff = selected_difficulty if selected_game_key != 'dodge' else "MEDIUM"
        current_game.reset(diff)
        is_paused = False
        modal = None

    def prep_start(key, name):
        nonlocal state, selected_game_key, modal
        selected_game_key = key
        state = 'input_name'
        modal = ModalInput("ENTER PLAYER NAME:")
        audio.stop_music()

    menu_btns = [
        Button("COLLECTOR", cfg.SCREEN_WIDTH//2-180, 250, 360, 60, cfg.ACCENT_GREEN, lambda: prep_start('collector', 'COLLECTOR'), fM),
        Button("NEON DODGE", cfg.SCREEN_WIDTH//2-180, 330, 360, 60, cfg.ACCENT_ORANGE, lambda: prep_start('dodge', 'NEON DODGE'), fM),
        Button("REACTION RUSH", cfg.SCREEN_WIDTH//2-180, 410, 360, 60, cfg.ACCENT_PINK, lambda: prep_start('reaction', 'REACTION RUSH'), fM),
        Button("LEADERBOARD", cfg.SCREEN_WIDTH//2-180, 490, 360, 60, cfg.ACCENT_YELLOW, lambda: set_state('leaderboard'), fM),
        Button("QUIT", cfg.SCREEN_WIDTH//2-180, 570, 360, 60, cfg.ACCENT_RED, lambda: [pygame.quit(), sys.exit()], fM)
    ]

    def set_state(s):
        nonlocal state
        state = s

    audio.start_lobby_music()
    running = True

    while running:
        dt = clock.tick(cfg.FPS) / 1000.0
        events = pygame.event.get()
        clicks = [e.pos for e in events if e.type == pygame.MOUSEBUTTONDOWN]
        pos = pygame.mouse.get_pos()

        for ev in events:
            if ev.type == pygame.QUIT: running = False
            if ev.type == pygame.KEYDOWN and ev.key == pygame.K_ESCAPE:
                if state == 'playing': is_paused = not is_paused
                elif state in ['gameover', 'leaderboard', 'input_name', 'input_diff']: go_back()

        screen.fill(cfg.BG_PRIMARY)
        bg.draw(screen, dt)

        if state == 'menu':
            draw_glowing_text(screen, "ARENA", fL, cfg.ACCENT_BLUE, (cfg.SCREEN_WIDTH//2, 140))
            draw_glowing_text(screen, "Professional Interactive Arcade Suite", fS, cfg.TEXT_SECONDARY, (cfg.SCREEN_WIDTH//2, 210))
            for b in menu_btns: b.update(pos, events); b.draw(screen)

        elif state == 'input_name':
            modal.draw(screen, fL, fM, fS)
            for ev in events:
                if ev.type == pygame.KEYDOWN:
                    if ev.key == pygame.K_RETURN and modal.input_text.strip():
                        player_name = modal.input_text.strip()
                        if selected_game_key == 'dodge':
                            start_game()
                        else:
                            state = 'input_diff'
                            modal = ModalInput("SELECT DIFFICULTY:", options=cfg.DIFFICULTIES)
                    elif ev.key == pygame.K_BACKSPACE: modal.input_text = modal.input_text[:-1]
                    elif ev.unicode.isalpha() and len(modal.input_text) < 15: modal.input_text += ev.unicode

        elif state == 'input_diff':
            modal.draw(screen, fL, fM, fS)
            for ev in events:
                if ev.type == pygame.KEYDOWN:
                    if ev.key == pygame.K_RETURN:
                        selected_difficulty = modal.options[modal.selected_idx]
                        start_game()
                    elif ev.key == pygame.K_UP: modal.selected_idx = (modal.selected_idx - 1) % len(modal.options)
                    elif ev.key == pygame.K_DOWN: modal.selected_idx = (modal.selected_idx + 1) % len(modal.options)

        elif state == 'playing' and current_game:
            if not is_paused:
                res = current_game.update(dt, pygame.key.get_pressed(), clicks)
                final_score, lives = res[0], res[1]
                current_game.draw(screen)
                if not current_game.running:
                    state = 'gameover'
                    lb.add(player_name, final_score, game_name, getattr(current_game, 'difficulty', 'N/A'))
                    audio.play_sfx(523, 0.5, 0.4)
            else:
                overlay = pygame.Surface(screen.get_size(), pygame.SRCALPHA)
                overlay.fill((10, 12, 24, 200))
                screen.blit(overlay, (0,0))
                draw_glowing_text(screen, "PAUSED", fL, cfg.ACCENT_YELLOW, (cfg.SCREEN_WIDTH//2, 240))
                pause_resume_btn.update(pos, events); pause_resume_btn.draw(screen)
                pause_menu_btn.update(pos, events); pause_menu_btn.draw(screen)
                for c in clicks:
                    if pause_resume_btn.rect.collidepoint(c): is_paused = False
                    if pause_menu_btn.rect.collidepoint(c): go_back()

        elif state == 'gameover':
            # Full dark overlay
            overlay = pygame.Surface(screen.get_size(), pygame.SRCALPHA)
            overlay.fill((10, 12, 24, 220))
            screen.blit(overlay, (0,0))
            
            # Draw decorative elements
            box = pygame.Rect(cfg.SCREEN_WIDTH//2-250, 100, 500, 550)
            pygame.draw.rect(screen, (25, 30, 50), box, border_radius=15)
            pygame.draw.rect(screen, cfg.ACCENT_BLUE, box, 3, border_radius=15)
            
            # Adjusted vertical spacing
            draw_glowing_text(screen, "GAME OVER", fL, cfg.ACCENT_RED, (cfg.SCREEN_WIDTH//2, 160))
            draw_glowing_text(screen, f"Player: {player_name}", fM, cfg.ACCENT_BLUE, (cfg.SCREEN_WIDTH//2, 250))
            draw_glowing_text(screen, f"SCORE: {final_score}", fL, cfg.ACCENT_YELLOW, (cfg.SCREEN_WIDTH//2, 330))
            
            # FIXED: Moved buttons DOWN and INSIDE the box
            pause_resume_btn.text = "PLAY AGAIN"
            pause_resume_btn.rect.y = 470  # Moved down significantly
            pause_menu_btn.rect.y = 550    # Moved down significantly
            
            pause_resume_btn.update(pos, events); pause_resume_btn.draw(screen)
            pause_menu_btn.update(pos, events); pause_menu_btn.draw(screen)
            
            for c in clicks:
                if pause_resume_btn.rect.collidepoint(c): start_game(); is_paused=False
                if pause_menu_btn.rect.collidepoint(c): go_back()

        elif state == 'leaderboard':
            # Full background overlay
            overlay = pygame.Surface(screen.get_size(), pygame.SRCALPHA)
            overlay.fill((10, 12, 24, 220))
            screen.blit(overlay, (0,0))
            
            # Draw container
            box = pygame.Rect(cfg.SCREEN_WIDTH//2-400, 60, 800, 680)
            pygame.draw.rect(screen, (25, 30, 50), box, border_radius=15)
            pygame.draw.rect(screen, cfg.ACCENT_YELLOW, box, 3, border_radius=15)
            
            draw_glowing_text(screen, "LEADERBOARD", fL, cfg.ACCENT_YELLOW, (cfg.SCREEN_WIDTH//2, 110))
            
            top = lb.scores[:10]
            for i, e in enumerate(top):
                c = cfg.ACCENT_YELLOW if i==0 else cfg.ACCENT_BLUE if i<3 else cfg.TEXT_PRIMARY
                diff = e.get('diff', 'N/A')
                game = e.get('game', 'UNKNOWN')
                name = e.get('name', 'Player')
                score = e.get('score', 0)
                
                txt = f"{i+1}. {name} | {score} pts | {game} ({diff})"
                draw_glowing_text(screen, txt, fS, c, (cfg.SCREEN_WIDTH//2, 190 + i*48))
            
            draw_glowing_text(screen, "Press ESC to go back", fM, cfg.ACCENT_GREEN, (cfg.SCREEN_WIDTH//2, 700))

        for p in particles[:]: p.update(dt); p.draw(screen)
        particles[:] = [p for p in particles if p.life > 0]
        pygame.display.flip()

    pygame.quit()

if __name__ == "__main__":
    main()